<div class="container-fluid sticky-top">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <a href="index.php"><img src="./img/abs_logo.png" height="80px" width="200px" alt="" srcset=""></a>
                </div>
               
                
                <nav class="navbar navbar-expand-lg navbar-light bg-white py-lg-0 px-lg-3">
                    <!-- <a href="index.html" class="navbar-brand d-lg-none">
                        <img src="./img/abs_logo.png" height="80px" width="200px" alt="" srcset="">
                    </a> -->
                    <button type="button" class="navbar-toggler me-0" data-bs-toggle="collapse"
                        data-bs-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav">
                            <a href="index.php" class="nav-item nav-link">Home</a>
                            <a href="about.php" class="nav-item nav-link">About Us</a>
 
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Services</a>
                                <div class="dropdown-menu bg-light m-0">
                                    <a href="./Personal_Care.php" class="dropdown-item">Personal Care</a>
                                    <a href="./Domiciliary_Care.php" class="dropdown-item">Domiciliary Care</a>
                                    <a href="./Complex_Care.php" class="dropdown-item">Complex Care</a>
                                    <a href="./Supported_Living.php" class="dropdown-item">Supported Living</a>
    
                                </div>
                            </div>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>
                        </div>
                        
                    </div>
                </nav>
            </div>
        </div>
        
    </div>