<div class="container-fluid py-2 d-none d-lg-flex bg-primary text-white">
        <div class="container">
            <div class="d-flex justify-content-between">
                <div>
                    <small class="me-3"><i class="fa fa-map-marker-alt me-2"></i>DA11 8LR, 108 Tennyson walk London</small>
                    <small class="me-3"><i class="fa fa-phone me-2"></i>+44 7474144702</small>
                    <small class="me-3"><i class="fa fa-envelope me-2"></i>info@absolutescare.com</small>
                    <!-- <small class="me-3"><i class="fa fa-clock me-2"></i>Mon-Sat 09am-5pm, Sun Closed</small> -->
                </div>
                
                <nav class="breadcrumb mb-0">
                    <a class="btn btn-sm-square btn-primary ms-2" href=""><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-sm-square btn-primary ms-2" href=""><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-sm-square btn-primary ms-2" href=""><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-sm-square btn-primary ms-2" href=""><i class="fab fa-youtube"></i></a>
                </nav>
            </div>
        </div>
    </div>